# 认证系统重构说明

## 问题描述
原项目存在登录逻辑问题，当用户长时间没有操作后再登录网页会一直闪烁刷新提示"请登录"，陷入死循环。

## 问题原因
1. 路由守卫中的无限重定向逻辑
2. 登录页面中的自动跳转逻辑
3. 缺少对token有效性的验证
4. 多处直接操作localStorage，缺乏统一管理

## 已修复的文件
- ✅ `src/router/index.js` - 路由守卫逻辑
- ✅ `src/views/login/index.vue` - 登录页面逻辑
- ✅ `src/utils/request.js` - 请求拦截器
- ✅ `src/views/layout/index.vue` - 布局组件
- ✅ `src/views/home/index.vue` - 首页
- ✅ `src/views/userInfo/index.vue` - 用户信息页

## 新增文件
- ✅ `src/utils/auth.js` - 统一认证工具函数

## 需要继续更新的文件
以下文件仍在使用旧的localStorage直接操作方式，需要更新为使用新的认证工具函数：

### 视图组件
- `src/views/study/index.vue` (4处)
- `src/views/chat/index.vue` (4处)
- `src/views/confession/index.vue` (4处)
- `src/views/lost/index.vue` (4处)
- `src/views/express/index.vue` (4处)
- `src/views/activity/index.vue` (4处)

### 工具文件
- `src/utils/maprequest.js` (1处)

## 更新步骤

### 1. 导入认证工具函数
在每个需要更新的文件顶部添加：
```javascript
import { getCurrentUser, isLoggedIn, setUserAuth, clearUserAuth } from '@/utils/auth.js'
```

### 2. 替换localStorage操作
将以下代码：
```javascript
const loginUser = JSON.parse(localStorage.getItem('loginUser'))
```

替换为：
```javascript
const loginUser = getCurrentUser()
```

### 3. 替换登录状态检查
将以下代码：
```javascript
const loginUser = localStorage.getItem('loginUser')
if (loginUser) {
  // 处理逻辑
}
```

替换为：
```javascript
if (isLoggedIn()) {
  // 处理逻辑
}
```

### 4. 替换用户信息设置
将以下代码：
```javascript
localStorage.setItem('loginUser', JSON.stringify(userInfo))
```

替换为：
```javascript
setUserAuth(userInfo)
```

### 5. 替换用户信息清除
将以下代码：
```javascript
localStorage.removeItem('loginUser')
```

替换为：
```javascript
clearUserAuth()
```

## 认证工具函数说明

### `isLoggedIn()`
检查用户是否已登录，返回布尔值

### `getCurrentUser()`
获取当前登录用户信息，返回用户对象或null

### `setUserAuth(userInfo)`
设置用户登录信息到localStorage

### `clearUserAuth()`
清除用户登录信息

### `isTokenValid()`
检查token是否有效（可扩展）

## 修复效果
1. 消除了无限重定向问题
2. 统一了认证状态管理
3. 提高了代码可维护性
4. 增强了token过期处理
5. 改善了用户体验

## 注意事项
1. 更新文件时注意保持原有业务逻辑不变
2. 测试每个更新后的功能是否正常
3. 确保所有需要用户认证的操作都使用新的工具函数
4. 可以根据实际需求扩展token过期检查逻辑
